# HAKO EVENTS V2

Projet HAKO EVENTS avec compte à rebours des événements.

Le workflow GitHub Actions se trouve dans `.github/workflows/build-apk.yml`.
Dans GitHub : Actions → Build HAKO EVENTS APK → Run workflow.
